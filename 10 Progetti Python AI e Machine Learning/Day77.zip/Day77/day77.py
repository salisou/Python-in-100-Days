import re
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from transformers import pipeline

# Download NLTK resources
nltk.download("punkt")
nltk.download("stopwords")

# Preprocessing function
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
    tokens = word_tokenize(text)
    tokens = [word for word in tokens if word not in stopwords.words("english")]
    return " ".join(tokens)

# Rule-Based Responses
def simple_chatbot(user_input):
    user_input = clean_text(user_input)
    
    responses = {
        "hello": "Hi there! How can I assist you?",
        "how are you": "I'm doing great! How about you?",
        "bye": "Goodbye! Have a wonderful day!",
        "thanks": "You're welcome! Let me know if you need anything else."
    }
    
    for key in responses:
        if key in user_input:
            return responses[key]
    
    return "I'm not sure I understand. Can you rephrase?"

# Load AI-Powered Chatbot
chatbot = pipeline("text-generation", model="microsoft/DialoGPT-medium")

def ai_chatbot(user_input):
    response = chatbot(user_input, max_length=100, num_return_sequences=1)
    return response[0]["generated_text"]

# Main Chatbot Function
def chatbot_system():
    print("Chatbot: Hello! Type 'exit' to stop.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("Chatbot: Goodbye! 👋")
            break
        elif any(word in user_input.lower() for word in ["hello", "bye", "thanks", "how are you"]):
            response = simple_chatbot(user_input)
        else:
            response = ai_chatbot(user_input)
        print(f"Chatbot: {response}")

# Run the chatbot
chatbot_system()




















# import nltk
# import re
# from nltk.tokenize import word_tokenize
# from nltk.corpus import stopwords
# from transformers import pipeline

# nltk.download("punkt")
# nltk.download("stopwords")


# # Load a pre-trained chatbot model
# chatbot = pipeline("text-generation", model="microsoft/DialoGPT-medium")

# def ai_chatbot(user_input):
#     response = chatbot(user_input, max_length=100, num_return_sequences=1)
#     return response[0]["generated_text"]

# # Example usage
# print(ai_chatbot("Hello how are you?"))



# def clean_text(text):
#     text = text.lower()
#     text = re.sub(r"[^a-zA-Z0-9\s]", "", text)  # Remove special characters
#     tokens = word_tokenize(text)
#     tokens = [word for word in tokens if word not in stopwords.words("english")]
#     return " ".join(tokens)

# # Example Usage
# # print(clean_text("Hello! How are you today?"))


# def simple_chatbot(user_input):
#     user_input = user_input.lower()
    
#     responses = {
#         "hello": "Hi there! How can I help you?",
#         "how are you": "I'm just a bot, but I'm doing great!",
#         "bye": "Goodbye! Have a nice day!",
#         "thanks": "You're welcome!"
#     }
    
#     for key in responses:
#         if key in user_input:
#             return responses[key]
    
#     return "I'm sorry, I didn't understand that."

# # Example Usage
# # print(simple_chatbot(" How are you"))



